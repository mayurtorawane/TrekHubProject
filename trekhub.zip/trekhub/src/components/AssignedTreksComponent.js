// import React, { useEffect, useState } from 'react';

// export default function AssignedTreksComponent() {
//   const user_id = localStorage.getItem("user_id");
//   const [treks, setTreks] = useState([]);
//   const [error, setError] = useState(null);
  
//   useEffect(() => {
//     if (user_id) {
//       fetch(`http://localhost:8080/userid/${user_id}`)
//         .then(response => {
//           if (!response.ok) {
//             throw new Error('Network response was not ok');
//           }
//           return response.json();
//         })
//         .then(loginId => {
//           return fetch(`http://localhost:8080/plantreks/${loginId}`)
//         })
//         .then(response => {
//           if (!response.ok) {
//             throw new Error('Network response was not ok');
//           }
//           return response.json();
//         })
//         .then(data => setTreks(data))
//         .catch(error => {
//           setError(error);
//           console.error('Error fetching data:', error);
//         });
//     }
//   }, [user_id]);

//  console.log(treks)
//   if (error) {
//     return <div>Error: {error.message}</div>;
//   }

//   return (
//     <div>
//       <h2>Assigned Treks for {user_id}</h2>
//       <table className="table table-bordered">
//         <thead>
//           <tr>
//             <th>Trek Name</th>
//             <th>Start-Date</th>
//             <th>Capacity</th>
//             <th>Duration</th>
//             <th>Status</th>
//           </tr>
//         </thead>
//         <tbody>
//           {treks.map((trek) => (
//             <tr key={trek.trek_id}>
//               <td>{trek.trekidobj.trek_name}</td>
//               <td>{trek.start_date}</td>
//               <td>{trek.trekidobj.capacity}</td>
//               <td>{trek.trekidobj.duration}</td>
//               <td>{trek.status}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

// import React, { useEffect, useState } from 'react';

// export default function AssignedTreksComponent() {
//   const user_id = localStorage.getItem("user_id");
//   const [treks, setTreks] = useState([]);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     if (user_id) {
//       fetch(`http://localhost:8080/userid/${user_id}`)
//         .then(response => {
//           if (!response.ok) {
//             throw new Error('Network response was not ok');
//           }
//           return response.json();
//         })
//         .then(loginId => {
//           return fetch(`http://localhost:8080/plantreks/${loginId}`)
//         })
//         .then(response => {
//           if (!response.ok) {
//             throw new Error('Network response was not ok');
//           }
//           return response.json();
//         })
//         .then(data => setTreks(data))
//         .catch(error => {
//           setError(error);
//           console.error('Error fetching data:', error);
//         });
//     }
//   }, [user_id]);

//   const handleStatusChange = (trekId, newStatus) => {
//     const updatedTreks = treks.map(trek => {
//       if (trek.trek_id === trekId) {
//         return { ...trek, status: newStatus };
//       }
//       return trek;
//     });

//     setTreks(updatedTreks);
//   };

//   if (error) {
//     return <div>Error: {error.message}</div>;
//   }

//   return (
//     <div>
//       <h2>Assigned Treks for {user_id}</h2>
//       <table className="table table-bordered">
//         <thead>
//           <tr>
//             <th>Trek Name</th>
//             <th>Start-Date</th>
//             <th>Capacity</th>
//             <th>Duration</th>
//             <th>Status</th>
//           </tr>
//         </thead>
//         <tbody>
//           {treks.map((trek) => (
//             <tr key={trek.trek_id}>
//               <td>{trek.trekidobj.trek_name}</td>
//               <td>{trek.start_date}</td>
//               <td>{trek.trekidobj.capacity}</td>
//               <td>{trek.trekidobj.duration}</td>
//               <td>
//                     <select
//                       value={trek.status}
//                       onChange={(e) => handleStatusChange(trek.trek_id, e.target.value)
//                       }
               
//                     >
//                       <option value="Upcoming">Upcoming</option>
//                       <option value="Completed">Completed</option>
                      
//                     </select>
                   
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }


import React, { useEffect, useState } from 'react';

export default function AssignedTreksComponent() {
  const user_id = localStorage.getItem("user_id");
  const [treks, setTreks] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (user_id) {
      fetch(`http://localhost:8080/userid/${user_id}`)
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(loginId => {
          return fetch(`http://localhost:8080/plantreks/${loginId}`)
        })
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => setTreks(data))
        .catch(error => {
          setError(error);
          console.error('Error fetching data:', error);
        });
    }
  }, [user_id]);

  const handleStatusChange = async (trekId, newStatus) => {
    const updatedTreks = treks.map(trek => {
      if (trek.trek_id === trekId) {
        return { ...trek, status: newStatus };
      }
      return trek;
    });

    setTreks(updatedTreks);

    // Call your backend API to update the status
    try {
      const response = await fetch(`http://localhost:8080/updateStatus`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ trekId, newStatus }), // Adjust this payload as per your backend requirements
      });

      if (!response.ok) {
        throw new Error('Failed to update status in the backend.');
      }
    } catch (error) {
      console.error('Error updating status in the backend:', error);
    }
  };

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    <div>
      <h2>Assigned Treks for {user_id}</h2>
      <table className="table table-bordered">
        <thead>
          {/* Table headers */}
        </thead>
        <tbody>
          {treks.map((trek) => (
            <tr key={trek.trek_id}>
              <td>{trek.trekidobj.trek_name}</td>
              <td>{trek.start_date}</td>
              <td>{trek.trekidobj.capacity}</td>
              <td>{trek.trekidobj.duration}</td>
              <td>
                <select
                  value={trek.status}
                  onChange={(e) => handleStatusChange(trek.trek_id, e.target.value)}
                >
                  <option value="Upcoming">ongoing</option>
                  <option value="Completed">Completed</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
